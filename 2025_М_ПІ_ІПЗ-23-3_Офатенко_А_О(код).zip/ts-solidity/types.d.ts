// //REMOVE .d.ts, make normal ts
// // Data types
// declare type uint256 = number;
// declare function uint256(a: any): uint256;

// declare global {
//   var External: never;
// }

// // Function types
// declare function emit(name: string, ...args: any[]): void;

// // Method decorators
// type MethodDecorator = (
//   target: any,
//   propertyKey: string,
//   descriptor: PropertyDescriptor,
// ) => PropertyDescriptor;

// declare const Public: MethodDecorator;
// declare const Payable: MethodDecorator;
// declare const External: MethodDecorator;
// declare const Pure: MethodDecorator;

// // Property decorators
// declare function Public(target: any, propertyKey: string): void;
// declare function Indexed(target: any, propertyKey: string): void;

// declare function event1(obj: Record<string, any>): void;
