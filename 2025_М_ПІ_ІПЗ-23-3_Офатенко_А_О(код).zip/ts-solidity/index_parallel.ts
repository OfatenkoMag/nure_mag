import 'reflect-metadata';
import { Project } from "ts-morph";
import * as fs from "node:fs/promises";
import { fork } from 'child_process';
import path from 'path';

const project = new Project();
project.addSourceFilesAtPaths("contracts/**/*.ts");
const files = project.getSourceFiles();
const distFolder = "./compiled";

function createWorker() {
  return fork(path.join(__dirname, 'worker.ts'));
}

async function compileClass(classDeclaration: any, index: number): Promise<string> {
  return new Promise((resolve) => {
    const worker = createWorker();
    worker.on('message', (result: string) => {
      resolve(result);
      worker.kill();
    });
    worker.send({ classDeclaration, index });
  });
}

async function processFile(file: any) {
  const classes = file.getClasses();
  const compiled = await Promise.all(
    classes.map((classDeclaration: any, index: number) => 
      compileClass(classDeclaration, index)
    )
  );
  return { file, compiled };
}

async function ensureDistFolder() {
  try {
    await fs.access(distFolder);
  } catch (e) {
    await fs.mkdir(distFolder);
  }
}

async function writeFile(file: any, compiled: string[]) {
  await fs.writeFile(
    `${distFolder}/${file.getBaseNameWithoutExtension()}.sol`,
    compiled.join('\n\n')
  );
}

(async () => {
  await ensureDistFolder();
  
  const processedFiles = await Promise.all(
    files.map(file => processFile(file))
  );

  await Promise.all(
    processedFiles.map(({ file, compiled }) => 
      writeFile(file, compiled)
    )
  );
})(); 
