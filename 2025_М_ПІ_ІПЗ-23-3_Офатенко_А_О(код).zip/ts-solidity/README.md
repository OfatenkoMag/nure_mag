#### Contract needs to be function that allows multiple inheritance
``
class Test extends Contract() {}
``

``
class Test extends Event {}
``

``
class Test extends Error {}
``

``
class Test extends Struct {}
``


ref arg as function argument - calldata after type (unit256[] calldata arg)

in func body - always memory