// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import "@openzeppelin/contracts/security/ReentrancyGuard.sol";

contract TimeLockedWallet is ReentrancyGuard {
    address public owner;
    uint256 public unlockTime;
    mapping(address => uint256) public balances;
    mapping(address => uint256) public lockTimes;

    event Deposited(address indexed depositor, uint256 amount, uint256 unlockTime);
    event Withdrawn(address indexed withdrawer, uint256 amount);

    constructor() {
        owner = msg.sender;
    }

    function deposit(uint256 lockDuration) external payable nonReentrant {
        require(msg.value > 0, "Must deposit some ETH");
        require(lockDuration > 0, "Lock duration must be positive");

        uint256 unlockTime_ = block.timestamp + lockDuration;
        balances[msg.sender] += msg.value;
        lockTimes[msg.sender] = unlockTime_;

        emit Deposited(msg.sender, msg.value, unlockTime_);
    }

    function withdraw() external nonReentrant {
        require(balances[msg.sender] > 0, "No balance to withdraw");
        require(block.timestamp >= lockTimes[msg.sender], "Funds are still locked");

        uint256 amount = balances[msg.sender];
        balances[msg.sender] = 0;
        lockTimes[msg.sender] = 0;

        payable(msg.sender).transfer(amount);
        emit Withdrawn(msg.sender, amount);
    }

    function getBalance(address account) external view returns (uint256) {
        return balances[account];
    }

    function getUnlockTime(address account) external view returns (uint256) {
        return lockTimes[account];
    }

    function isLocked(address account) external view returns (bool) {
        return block.timestamp < lockTimes[account];
    }

    function extendLock(uint256 additionalTime) external {
        require(balances[msg.sender] > 0, "No balance to extend lock");
        require(additionalTime > 0, "Additional time must be positive");

        lockTimes[msg.sender] += additionalTime;
    }
} 