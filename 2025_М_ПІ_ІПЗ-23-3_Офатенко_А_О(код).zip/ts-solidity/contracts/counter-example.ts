class Counter {
  @Public
  counter: uint256 = 0;

  constructor() {}

  @Public
  setCounter(value: uint256) {
    this.counter = value;
  }

  increment() {
    this.counter++;
    // emit("CounterIncremented", this.counter);
  }
}

class EventPay extends Event {

}



class Test extends Contract() {
  @Public
  private counter: uint256 = 0;

  eventPay2 = event1({ a: uint256 });
  EventPay = class {
    constructor(@Indexed public a: uint256) {}
  };

  constructor(private readonly value: uint256) {
    this.counter = value;
  }

  @External
  setCounter(value: uint256) {
    this.counter = value;
  }

  @Pure
  @Public
  increment() {
    this.counter++;
    emit(new EventPay(this.counter));
  }

  @Pure
  @Public
  lessThanTen(value: uint256) {
    return value < 10;
  }
}
