import { Contract, uint256 } from "@/types";
import { Public, Pure, External } from "@/decorators";

class Counter {
  @Public
  counter: uint256 = 0;

  constructor() {}

  @Public
  setCounter(value: uint256) {
    this.counter = value;
  }

  increment() {
    this.counter++;
    // emit("CounterIncremented", this.counter);
  }
}


class Test extends Contract() {
  constructor(@Public() private readonly value: uint256) {
    super();
    this.counter = value;
  }

  @External
  setCounter(value: uint256) {
    this.counter = value;
  }

  @Pure
  @Public
  increment() {
    this.counter++;
  }

  @Pure
  @Public
  lessThanTen(value: uint256) {
    return value < 10;
  }
}
