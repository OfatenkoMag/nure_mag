// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";

contract TokenSwap {
    IERC20 public tokenA;
    IERC20 public tokenB;
    uint256 public rate;

    event Swap(address indexed user, uint256 amountA, uint256 amountB);

    constructor(address _tokenA, address _tokenB, uint256 _rate) {
        tokenA = IERC20(_tokenA);
        tokenB = IERC20(_tokenB);
        rate = _rate;
    }

    function swap(uint256 amountA) external {
        require(tokenA.transferFrom(msg.sender, address(this), amountA), "Transfer failed");
        uint256 amountB = amountA * rate;
        require(tokenB.transfer(msg.sender, amountB), "Transfer failed");
        emit Swap(msg.sender, amountA, amountB);
    }
} 