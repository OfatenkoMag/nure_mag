// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";

contract Vault is ReentrancyGuard {
    IERC20 public token;
    mapping(address => uint256) public deposits;
    uint256 public totalDeposits;
    uint256 public interestRate;
    uint256 public lastInterestUpdate;

    event Deposit(address indexed user, uint256 amount);
    event Withdraw(address indexed user, uint256 amount);
    event InterestPaid(address indexed user, uint256 amount);

    constructor(address _token, uint256 _interestRate) {
        token = IERC20(_token);
        interestRate = _interestRate;
        lastInterestUpdate = block.timestamp;
    }

    function deposit(uint256 amount) external nonReentrant {
        require(amount > 0, "Amount must be greater than 0");
        require(token.transferFrom(msg.sender, address(this), amount), "Transfer failed");
        
        deposits[msg.sender] += amount;
        totalDeposits += amount;
        
        emit Deposit(msg.sender, amount);
    }

    function withdraw(uint256 amount) external nonReentrant {
        require(amount > 0, "Amount must be greater than 0");
        require(deposits[msg.sender] >= amount, "Insufficient balance");
        
        uint256 interest = calculateInterest(msg.sender);
        deposits[msg.sender] -= amount;
        totalDeposits -= amount;
        
        require(token.transfer(msg.sender, amount + interest), "Transfer failed");
        
        emit Withdraw(msg.sender, amount);
        emit InterestPaid(msg.sender, interest);
    }

    function calculateInterest(address user) public view returns (uint256) {
        uint256 timeElapsed = block.timestamp - lastInterestUpdate;
        return (deposits[user] * interestRate * timeElapsed) / (365 days * 100);
    }

    function updateInterestRate(uint256 newRate) external {
        require(msg.sender == address(this), "Only vault can update rate");
        interestRate = newRate;
        lastInterestUpdate = block.timestamp;
    }
} 