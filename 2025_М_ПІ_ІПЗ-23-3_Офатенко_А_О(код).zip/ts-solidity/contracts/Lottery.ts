// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import "@openzeppelin/contracts/security/ReentrancyGuard.sol";

contract Lottery is ReentrancyGuard {
    address public manager;
    address[] public players;
    uint256 public ticketPrice;
    uint256 public prizePool;
    bool public isActive;

    event TicketPurchased(address indexed player, uint256 amount);
    event WinnerSelected(address indexed winner, uint256 prize);
    event LotteryStarted(uint256 ticketPrice);
    event LotteryEnded();

    constructor(uint256 _ticketPrice) {
        manager = msg.sender;
        ticketPrice = _ticketPrice;
        isActive = true;
    }

    function buyTicket() external payable nonReentrant {
        require(isActive, "Lottery is not active");
        require(msg.value == ticketPrice, "Incorrect ticket price");

        players.push(msg.sender);
        prizePool += msg.value;

        emit TicketPurchased(msg.sender, msg.value);
    }

    function selectWinner() external nonReentrant {
        require(msg.sender == manager, "Only manager can select winner");
        require(players.length > 0, "No players in lottery");
        require(isActive, "Lottery is not active");

        uint256 winnerIndex = uint256(keccak256(abi.encodePacked(block.timestamp, block.prevrandao))) % players.length;
        address winner = players[winnerIndex];

        isActive = false;
        uint256 prize = prizePool;
        prizePool = 0;

        payable(winner).transfer(prize);
        delete players;

        emit WinnerSelected(winner, prize);
        emit LotteryEnded();
    }

    function startNewLottery(uint256 _ticketPrice) external {
        require(msg.sender == manager, "Only manager can start lottery");
        require(!isActive, "Lottery is already active");

        ticketPrice = _ticketPrice;
        isActive = true;

        emit LotteryStarted(_ticketPrice);
    }

    function getPlayers() external view returns (address[] memory) {
        return players;
    }

    function getPrizePool() external view returns (uint256) {
        return prizePool;
    }
} 