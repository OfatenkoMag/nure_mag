export function Pure(target: any, propertyKey: string) {
}

export function Public(target?: any, propertyKey?: string) {
}

export function External(target: any, propertyKey: string) {
}
 

export function Indexed(target: Object, propertyKey: string | symbol, parameterIndex: number) {
  const existingMetadata: number[] = Reflect.getOwnMetadata('indexed_parameters', target, propertyKey) || [];
  existingMetadata.push(parameterIndex);
  Reflect.defineMetadata('indexed_parameters', existingMetadata, target, propertyKey);
}