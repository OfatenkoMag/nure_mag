import { TsSolidityType } from "./constants";

type MethodDecorator = (
  target: any,
  propertyKey: string,
  descriptor: PropertyDescriptor,
) => PropertyDescriptor;

export type Public = MethodDecorator;
export type Payable = MethodDecorator;
export type External = MethodDecorator;
export type Pure = MethodDecorator;
export type View = MethodDecorator;

export type uint256 = number;
export type address = `0x${string}`;


// Multiple inheritance
export interface Type<T = any> extends Function {
  new (...args: any[]): T;
}
type UnionToIntersection<U> = (U extends any ? (k: U) => void : never) extends (k: infer I) => void ? I : never;
type ClassRefsToConstructors<T extends Type[]> = {
    [U in keyof T]: T[U] extends Type<infer V> ? V : never;
};
type Intersection<T extends Type[]> = Type<UnionToIntersection<ClassRefsToConstructors<T>[number]>>;
export declare function Contract<T extends Type[] = []>(...classRefs: T): Intersection<T>;