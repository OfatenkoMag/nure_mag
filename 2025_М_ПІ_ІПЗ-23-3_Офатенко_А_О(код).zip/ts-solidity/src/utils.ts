import {
  ClassDeclaration,
  ParameterDeclaration,
  PropertyDeclaration,
  Statement,
} from "ts-morph";

export const compileClassToContract = (classDeclaration: ClassDeclaration) => {
  return `contract ${classDeclaration?.getName()} {`;
};

export const compileProperty = (property: PropertyDeclaration) => {
  const propertyName = property.getName();
  const propertyType = property.getType().getText();
  return `\t${propertyType} public ${propertyName};\n`;
};

export const compileMethodParams = (parameter: ParameterDeclaration) => {
  const paramName = parameter.getName();
  const paramType = parameter.getType().getText();
  return `${paramType} ${paramName}`;
};

export const compileMethodBody = (statement: Statement) => {
  const statementText = statement.getText();
  return `${statementText.replace("this.", "")}`;
};

export const lineBreak = (str: string) => {
  return `${str}\n}`;
};

export const spaceStart = (str: string, spaces: number) => {
  return `${" ".repeat(spaces)}${str}`;
};

export function addLineBreaks(str?: string, count = 1) {
  if (!str?.trim()) return "";
  const lineBreaks = "\n".repeat(count);
  return `${str}${lineBreaks}`;
}

// TODO
// function emit(event: Event) {}
// function revert(err: Error): never

// function mapping(key: SolidityType, value: SolidityType) {}
