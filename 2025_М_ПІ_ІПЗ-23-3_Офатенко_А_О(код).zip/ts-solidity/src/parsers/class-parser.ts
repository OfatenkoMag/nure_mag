import {
  ClassDeclaration,
  Decorator,
  ParameterDeclaration,
  Statement,
} from "ts-morph";
import { addLineBreaks, spaceStart } from "@/utils";

export class ClassParser {
  private options: ClassParserOptions;

  constructor(
    private readonly cls: ClassDeclaration,
    options?: Partial<ClassParserOptions>,
  ) {
    this.options = { ...defaultOptions, ...options };
  }

  public compile() {
    const contractName = addLineBreaks(this.getContractName());
    const properties = addLineBreaks(
      this.getProperties()
        .map((property) => spaceStart(property, this.options.tabSize))
        .join("\n"),
      2,
    );

    const constructor = addLineBreaks(
      spaceStart(this.getConstructor(), this.options.tabSize),
      2,
    );
    const methods = this.getMethods().join("\n");

    return `${contractName}${properties}${constructor}${methods}}`;
  }

  private getContractName() {
    return `contract ${this.cls.getName()} {`;
  }

  private getProperties() {
    return this.cls?.getProperties().map((property) => {
      const propertyName = property.getName();
      const propertyType = property.getType().getText();
      const viewModifiers = this.getDecoratorNames(
        property.getDecorators(),
      ).toLowerCase();

      return `${propertyType} ${viewModifiers} ${propertyName};`;
    });
  }

  private getMethods() {
    return this.cls?.getMethods().map((method) => {
      const methodParams = method
        .getParameters()
        .map(this.getMethodParameters)
        .join(", ");

      const viewModifiers = this.getDecoratorNames(
        method.getDecorators(),
      ).toLowerCase();
      const body = method.getStatements().map(this.getMethodBody).join("\n");

      return spaceStart(
        `function ${method.getName()}(${methodParams}) ${viewModifiers} {\n` +
          `${spaceStart(body, 2 * this.options.tabSize)}\n` +
          `${spaceStart("}", this.options.tabSize)}\n`,
        this.options.tabSize,
      );
    });
  }

  private getMethodBody(statement: Statement) {
    const statementText = statement.getText();
    return `${statementText.replace("this.", "")}`;
  }

  private getDecoratorNames(decorators: Decorator[]) {
    return decorators.map((decorator) => decorator.getName()).join(" ");
  }

  private getMethodParameters(param: ParameterDeclaration) {
    const paramName = param.getName();
    const paramType = param.getType().getText();
    return `${paramType} ${paramName}`;
  }

  private getConstructor() {
    const constructors = this.cls.getConstructors();

    if (constructors.length === 0) return "";

    const constructor = constructors[0];

    const params = constructor
      .getParameters()
      .map(this.getMethodParameters)
      .join(", ");

    const body = constructor.getStatements().map(this.getMethodBody).join("\n");

    if (!body) return "";

    return (
      `constructor(${params}) {\n` +
      `${spaceStart(body, 2 * this.options.tabSize)}\n` +
      `${spaceStart("}", this.options.tabSize)}`
    );
  }
}

export type ClassParserOptions = {
  tabSize: number;
};

const defaultOptions: ClassParserOptions = {
  tabSize: 2,
};
