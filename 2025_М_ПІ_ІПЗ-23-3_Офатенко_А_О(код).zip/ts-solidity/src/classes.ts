export class Event {}
export class Error {}
export class Struct {}