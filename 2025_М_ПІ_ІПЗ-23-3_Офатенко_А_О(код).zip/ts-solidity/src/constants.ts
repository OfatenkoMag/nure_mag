export const pragma = "pragma solidity ^0.8.0;";

export const TsSolidityType = {
  unit256: "uint256",
  address: "address",
} as const;
