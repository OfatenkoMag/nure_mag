import 'reflect-metadata';
import { Project } from "ts-morph";
import * as fs from "node:fs/promises";

import { ClassParser } from "@/parsers/class-parser";

const project = new Project();
project.addSourceFilesAtPaths("contracts/**/*.ts");
const files = project.getSourceFiles();

const compiledFiles = files.map((file) => {
  const compiled = file?.getClasses().map((classDeclaration, index) => {
    const contract = new ClassParser(classDeclaration).compile();
    const pragma = index === 0 ? "pragma solidity ^0.8.0;" : "";
    return `${pragma}\n\n${contract}`;
  });

  return { file, compiled };
});

const distFolder = "./compiled";
(async () => {
  try {
    await fs.access(distFolder);
  } catch (e) {
    await fs.mkdir(distFolder);
  } finally {
    for await (const { compiled, file } of compiledFiles) {
      fs.writeFile(
        `${distFolder}/${file.getBaseNameWithoutExtension()}.sol`,
        compiled,
      );
    }
  }
})();
