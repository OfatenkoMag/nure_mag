import { parentPort } from 'worker_threads';
import { ClassParser } from "@/parsers/class-parser";

parentPort?.on('message', (data: { classDeclaration: any, index: number }) => {
  const { classDeclaration, index } = data;
  const contract = new ClassParser(classDeclaration).compile();
  const pragma = index === 0 ? "pragma solidity ^0.8.0;" : "";
  parentPort?.postMessage(`${pragma}\n\n${contract}`);
}); 